-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2025 at 10:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cars1`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `year` year(4) NOT NULL,
  `horsepower` int(11) NOT NULL,
  `mileage` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `name`, `model`, `year`, `horsepower`, `mileage`, `price`, `created_at`, `updated_at`) VALUES
(1, 'Car 1', 'Model 1', '2019', 155, 55373, 23999.00, NULL, NULL),
(2, 'Car 2', 'Model 2', '2020', 163, 90880, 31488.00, NULL, NULL),
(3, 'Car 3', 'Model 3', '2022', 116, 31997, 40280.00, NULL, NULL),
(4, 'Car 4', 'Model 4', '2019', 461, 58697, 47917.00, NULL, NULL),
(5, 'Car 5', 'Model 5', '2017', 181, 9667, 7954.00, NULL, NULL),
(6, 'Car 6', 'Model 6', '2021', 273, 39322, 10401.00, NULL, NULL),
(7, 'Car 7', 'Model 7', '2016', 195, 91783, 25409.00, NULL, NULL),
(8, 'Car 8', 'Model 8', '2018', 393, 78629, 38190.00, NULL, NULL),
(9, 'Car 9', 'Model 9', '2011', 134, 51727, 38007.00, NULL, NULL),
(10, 'Car 10', 'Model 10', '2013', 203, 2316, 19735.00, NULL, NULL),
(11, 'Car 11', 'Model 11', '2018', 128, 75569, 45129.00, NULL, NULL),
(12, 'Car 12', 'Model 12', '2016', 241, 66389, 38498.00, NULL, NULL),
(13, 'Car 13', 'Model 13', '2020', 408, 96938, 35002.00, NULL, NULL),
(14, 'Car 14', 'Model 14', '2016', 194, 19300, 7070.00, NULL, NULL),
(15, 'Car 15', 'Model 15', '2013', 128, 49299, 16211.00, NULL, NULL),
(16, 'Car 16', 'Model 16', '2018', 142, 57558, 33706.00, NULL, NULL),
(17, 'Car 17', 'Model 17', '2013', 253, 78538, 9276.00, NULL, NULL),
(18, 'Car 18', 'Model 18', '2023', 140, 19601, 45622.00, NULL, NULL),
(19, 'Car 19', 'Model 19', '2017', 330, 74077, 28017.00, NULL, NULL),
(20, 'Car 20', 'Model 20', '2014', 367, 7623, 41766.00, NULL, NULL),
(21, 'Car 21', 'Model 21', '2013', 137, 51611, 21694.00, NULL, NULL),
(22, 'Car 22', 'Model 22', '2010', 430, 80390, 35670.00, NULL, NULL),
(23, 'Car 23', 'Model 23', '2015', 241, 59203, 43863.00, NULL, NULL),
(24, 'Car 24', 'Model 24', '2023', 371, 32635, 29192.00, NULL, NULL),
(25, 'Car 25', 'Model 25', '2013', 170, 35379, 39855.00, NULL, NULL),
(27, 'Car 27', 'Model 27', '2020', 439, 35124, 23855.00, NULL, NULL),
(28, 'Car 28', 'Model 28', '2019', 299, 98064, 42944.00, NULL, NULL),
(29, 'Car 29', 'Model 29', '2010', 473, 40270, 26862.00, NULL, NULL),
(30, 'Car 30', 'Model 30', '2022', 307, 99352, 41820.00, NULL, NULL),
(32, 'bmw', 'model 10', '2015', 300, 50000, 40000.00, '2025-02-18 16:19:05', '2025-02-18 16:19:05'),
(34, 'kia', '129880', '2005', 300, 30000, 5000.00, '2025-02-18 17:31:58', '2025-02-18 17:31:58');

-- --------------------------------------------------------

--
-- Table structure for table `car_images`
--

CREATE TABLE `car_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `car_id` bigint(20) UNSIGNED NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `car_images`
--

INSERT INTO `car_images` (`id`, `car_id`, `image_url`, `created_at`, `updated_at`) VALUES
(1, 1, 'image.jpg', NULL, NULL),
(2, 1, 'image.jpg', NULL, NULL),
(3, 1, 'image.jpg', NULL, NULL),
(4, 1, 'image.jpg', NULL, NULL),
(5, 2, 'image.jpg', NULL, NULL),
(6, 2, 'image.jpg', NULL, NULL),
(7, 2, 'image.jpg', NULL, NULL),
(8, 2, 'image.jpg', NULL, NULL),
(9, 3, 'image.jpg', NULL, NULL),
(10, 3, 'image.jpg', NULL, NULL),
(11, 3, 'image.jpg', NULL, NULL),
(12, 3, 'image.jpg', NULL, NULL),
(13, 4, 'image.jpg', NULL, NULL),
(14, 5, 'image.jpg', NULL, NULL),
(15, 5, 'image.jpg', NULL, NULL),
(16, 5, 'image.jpg', NULL, NULL),
(17, 6, 'image.jpg', NULL, NULL),
(18, 6, 'image.jpg', NULL, NULL),
(19, 6, 'image.jpg', NULL, NULL),
(20, 6, 'image.jpg', NULL, NULL),
(21, 7, 'image.jpg', NULL, NULL),
(22, 8, 'image.jpg', NULL, NULL),
(23, 8, 'image.jpg', NULL, NULL),
(24, 8, 'image.jpg', NULL, NULL),
(25, 9, 'image.jpg', NULL, NULL),
(26, 9, 'image.jpg', NULL, NULL),
(27, 9, 'image.jpg', NULL, NULL),
(28, 9, 'image.jpg', NULL, NULL),
(29, 10, 'image.jpg', NULL, NULL),
(30, 11, 'image.jpg', NULL, NULL),
(31, 11, 'image.jpg', NULL, NULL),
(32, 11, 'image.jpg', NULL, NULL),
(33, 11, 'image.jpg', NULL, NULL),
(34, 12, 'image.jpg', NULL, NULL),
(35, 13, 'image.jpg', NULL, NULL),
(36, 13, 'image.jpg', NULL, NULL),
(37, 13, 'image.jpg', NULL, NULL),
(38, 14, 'image.jpg', NULL, NULL),
(39, 15, 'image.jpg', NULL, NULL),
(40, 16, 'image.jpg', NULL, NULL),
(41, 16, 'image.jpg', NULL, NULL),
(42, 16, 'image.jpg', NULL, NULL),
(43, 17, 'image.jpg', NULL, NULL),
(44, 17, 'image.jpg', NULL, NULL),
(45, 17, 'image.jpg', NULL, NULL),
(46, 18, 'image.jpg', NULL, NULL),
(47, 18, 'image.jpg', NULL, NULL),
(48, 18, 'image.jpg', NULL, NULL),
(49, 18, 'image.jpg', NULL, NULL),
(50, 19, 'image.jpg', NULL, NULL),
(51, 19, 'image.jpg', NULL, NULL),
(52, 19, 'image.jpg', NULL, NULL),
(53, 20, 'image.jpg', NULL, NULL),
(54, 21, 'image.jpg', NULL, NULL),
(55, 21, 'image.jpg', NULL, NULL),
(56, 21, 'image.jpg', NULL, NULL),
(57, 22, 'image.jpg', NULL, NULL),
(58, 22, 'image.jpg', NULL, NULL),
(59, 22, 'image.jpg', NULL, NULL),
(60, 23, 'image.jpg', NULL, NULL),
(61, 24, 'image.jpg', NULL, NULL),
(62, 24, 'image.jpg', NULL, NULL),
(63, 24, 'image.jpg', NULL, NULL),
(64, 24, 'image.jpg', NULL, NULL),
(65, 25, 'image.jpg', NULL, NULL),
(66, 25, 'image.jpg', NULL, NULL),
(67, 25, 'image.jpg', NULL, NULL),
(68, 25, 'image.jpg', NULL, NULL),
(72, 27, 'image.jpg', NULL, NULL),
(73, 27, 'image.jpg', NULL, NULL),
(74, 27, 'image.jpg', NULL, NULL),
(75, 28, 'image.jpg', NULL, NULL),
(76, 28, 'image.jpg', NULL, NULL),
(77, 28, 'image.jpg', NULL, NULL),
(78, 29, 'image.jpg', NULL, NULL),
(79, 29, 'image.jpg', NULL, NULL),
(80, 29, 'image.jpg', NULL, NULL),
(81, 29, 'image.jpg', NULL, NULL),
(82, 30, 'image.jpg', NULL, NULL),
(83, 30, 'image.jpg', NULL, NULL),
(84, 30, 'image.jpg', NULL, NULL),
(86, 32, 'uploads/car_images/1739902745_R.jpg', '2025-02-18 16:19:05', '2025-02-18 16:19:05'),
(88, 34, 'uploads/car_images/1739907118_607447.jpg', '2025-02-18 17:31:58', '2025-02-18 17:31:58');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(19, '0001_01_01_000000_create_users_table', 1),
(20, '0001_01_01_000001_create_cache_table', 1),
(21, '0001_01_01_000002_create_jobs_table', 1),
(22, '2025_01_24_193853_create_cars_table', 1),
(23, '2025_01_24_193929_create_car_images_table', 1),
(24, '2025_01_26_160511_add_admin_to_users_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('nmPvsh9F9fUr21zrUfY9Rp8mbLGLVNCyAIxer8yy', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidnFKcnloWEIwVXdTTmJWQmhzUnVOZHhwZFRrUlJYV1BrcTI5dUVwcyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9jcmVhdGUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1739907142);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `admin`, `remember_token`, `created_at`, `updated_at`) VALUES
(3, 'hussein shehab', 'husseinshehab5@gmail.com', NULL, '$2y$12$PuDaSXNLegp4NZQAh3kcaexxKUs/RIbZcE4f8/kf.l9RidiJGpey2', 1, NULL, '2025-02-15 08:19:45', '2025-02-15 08:19:45'),
(4, 'koko', 'mini@hotmail.com', NULL, '$2y$12$hQsUoYyV727J0wInaOB0AeUiOfIPNBkdwaxBH0WbOI340knOljWRC', 0, NULL, '2025-02-15 08:24:12', '2025-02-15 08:24:12'),
(5, 'hussein moussa', 'hussein_moussa@gmail.com', NULL, '$2y$12$LDJXcLmFV/HNJupvO7j3U.bsXeLgAktBucHf/JU4zfYRQUuDaBJUe', 0, NULL, '2025-02-17 12:57:18', '2025-02-17 12:57:18'),
(6, 'loulou', 'louai_darsa@gmail.com', NULL, '$2y$12$KqsiYP8X0dHamcQVIYbAsOhq3CA1rAsX4fnW1RQQszkXg8Yi7id4y', 0, NULL, '2025-02-18 14:21:49', '2025-02-18 14:21:49'),
(7, 'hhhh', 'hhhh@hotmail.com', NULL, '$2y$12$SVNheR2vRwyJrjE.0QAQFOuJnwGOUEEkEishtKu/uLhnoAjIEoZ/O', 1, NULL, '2025-02-18 16:27:03', '2025-02-18 16:27:03'),
(8, 'hasan', 'hasan_shehab@gmail.com', NULL, '$2y$12$2PA4sJk4lVSMCcLe.DssbOI/zoTlzBSXQrQYSx8MSDvtCDDxTJb7K', 1, NULL, '2025-02-18 17:19:07', '2025-02-18 17:19:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car_images`
--
ALTER TABLE `car_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `car_images_car_id_foreign` (`car_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `car_images`
--
ALTER TABLE `car_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `car_images`
--
ALTER TABLE `car_images`
  ADD CONSTRAINT `car_images_car_id_foreign` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
